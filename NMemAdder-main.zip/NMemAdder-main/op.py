from pyrogram import Client
import config
api = config.API_ID
hash = config.API_HASH
session = "AQA5Cav9bY1cdjIp6JK1UhfhkCmYrTe7rC0af9cMMBbhs3FzxiH9R1zaawaFbYdbgi8fds5XW3CCL9uY0enid4AOJ8aqciHjp7JqN8EfodKP0P3VFIV2nkwOygpvuceYScr9HfzKOEWY65J3YpAhVM-3mznh9meHmh_AVOy7DOVHuma-rtHytaD8JyJPpua7Mb4Kvv_l3wnfQDidZFBesRAk5yiUMAWUXxJ3GQw0lbkQLuK3IXEbYwXdMFulJienwW6SJvMaVjC2WZXQZmqNwM71UWpqVcO8DxuYW24db2y-MUbVrUpWtFRNN3NfA7rY25w0h6WkiIK4lfHqcoGowqV_AAAAAUM4vv4A"
app = Client(session_name=session, api_id = api, api_hash = hash) 












